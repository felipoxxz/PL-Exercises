﻿using Ex_16._1.DAO;
using Ex_16._1.Models;
using Microsoft.AspNetCore.Mvc;

namespace Ex_16._1.Controllers
{
    public class JogosController : Controller
    {
        public IActionResult Index()
        {
            List<JogosViewModel> listModel = new List<JogosViewModel>();
            listModel = GameDAO.AllSearch();
            return View(listModel);
        }
        public IActionResult Create()
        {
            JogosViewModel aluno = new JogosViewModel();
            aluno.dataAquisicao = DateTime.Now;
            return View("Form", aluno);
        }

        public IActionResult Salvar(JogosViewModel aluno)
        {
            try
            {
                GameDAO.Insert(aluno);
                return RedirectToAction("index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
            
        }
    }
}
