﻿using Ex_13._1.DAO;
using Ex_13._1.Models;
using Microsoft.AspNetCore.Mvc;

namespace Ex_13._1.Controllers
{
    public class JogosController : Controller
    {
        public IActionResult Index()
        {
            List<JogosViewModel> listModel = new List<JogosViewModel>();
            listModel = GameDAO.AllSearch();
            return View(listModel);
        }
    }
}
