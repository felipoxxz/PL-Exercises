﻿using System.Data.SqlClient;
using System.Data;

namespace Ex_13._1.DAO
{
    public class HelperDAO
    {
        internal static DataTable ExecutaSql(string sql, SqlParameter[] parametros)
        {
            using (SqlConnection conexao = ConnectionDB.GetConnection())
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conexao))
                {
                    if (parametros != null)
                        adapter.SelectCommand.Parameters.AddRange(parametros);
                    DataTable tabelaTemp = new DataTable();
                    adapter.Fill(tabelaTemp);
                    return tabelaTemp;
                }
            }
        }
    }
}
