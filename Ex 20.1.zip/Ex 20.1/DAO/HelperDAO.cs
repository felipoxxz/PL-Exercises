﻿using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Ex_20._1.Models;

namespace Ex_20._1.DAO
{
    public class HelperDAO
    {
        internal static DataTable ExecutaSql(string sql, SqlParameter[] parametros)
        {
            using (SqlConnection conexao = ConnectionDB.GetConnection())
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conexao))
                {
                    if (parametros != null)
                        adapter.SelectCommand.Parameters.AddRange(parametros);
                    DataTable tabelaTemp = new DataTable();
                    adapter.Fill(tabelaTemp);
                    return tabelaTemp;
                }
            }
        }
        internal static SqlParameter[] CreateParameters(JogosViewModel game)
        {
            SqlParameter[] parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("id", game.id);
            parameters[1] = new SqlParameter("descricao", game.descricao);
            parameters[2] = new SqlParameter("valor_locacao", game.valorLocacao);
            parameters[3] = new SqlParameter("data_aquisicao", game.dataAquisicao);
            parameters[4] = new SqlParameter("categoriaID", game.categoriaId);
            return parameters;
        }
    }
}
