﻿namespace Ex_20._1.Models
{
    public class JogosViewModel
    {
        public int id { get; set; }
        public string descricao { get; set; }
        public decimal valorLocacao { get; set; }
        public DateTime dataAquisicao { get; set; }
        public int categoriaId { get; set; }
    }
}
