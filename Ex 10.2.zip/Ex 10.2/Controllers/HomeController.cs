using Ex_10._2.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Ex_10._2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Converter(ConversorModel model)
        {
            if (ModelState.IsValid)
            {
                switch (model.Unidade)
                {
                    case "cm":
                        model.Resultado = model.Metros * 100;
                        break;
                    case "mm":
                        model.Resultado = model.Metros * 1000;
                        break;
                    case "km":
                        model.Resultado = model.Metros / 1000;
                        break;
                    case "ft":
                        model.Resultado = model.Metros * 3.28084;
                        break;
                    case "mi":
                        model.Resultado = model.Metros / 1609.34;
                        break;
                    default:
                        ModelState.AddModelError("", "Unidade de medida inv�lida.");
                        break;
                }
            }
            return View("Index", model); // Retorna o mesmo Model para a View
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
