﻿using System.ComponentModel.DataAnnotations;

namespace Ex_10._2.Models
{
    public class ConversorModel
    {
        [Required(ErrorMessage = "Por favor, insira um valor em metros.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "O valor deve ser maior que zero.")]
        public double Metros { get; set; }

        [Required(ErrorMessage = "Por favor, selecione uma unidade de medida.")]
        public string Unidade { get; set; }

        public double Resultado { get; set; }
    }
}
