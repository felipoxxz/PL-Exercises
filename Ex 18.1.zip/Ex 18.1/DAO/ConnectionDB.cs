﻿using System.Data.SqlClient;
namespace Ex_18._1.DAO
{
    public class ConnectionDB
    {
        public static SqlConnection GetConnection()
        {
            string strCon = "Data Source=DESKTOP-FTRI8H1\\MSSQLSERVER1; Database=AULADB; user id=sa; password=123456";
            SqlConnection conexao = new SqlConnection(strCon);
            conexao.Open();
            return conexao;
        }
    }
}
