﻿using Ex_18._1.DAO;
using Ex_18._1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

namespace Ex_18._1.Controllers
{
    public class JogosController : Controller
    {
        public IActionResult Index()
        {
            List<JogosViewModel> listModel = new List<JogosViewModel>();
            listModel = GameDAO.AllSearch();
            return View(listModel);
        }
        public IActionResult Create()
        {
            JogosViewModel aluno = new JogosViewModel();
            aluno.dataAquisicao = DateTime.Now;
            return View("Form", aluno);
        }

        public IActionResult Salvar(JogosViewModel aluno)
        {
            try
            {
                GameDAO dao = new GameDAO();
                if (dao.Search(aluno.id) == null)
                    GameDAO.Insert(aluno);
                else
                    GameDAO.Update(aluno);
                return RedirectToAction("index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }

        public IActionResult Edit(int id)
        {
            try
            {
                GameDAO dao = new GameDAO();
                JogosViewModel aluno = dao.Search(id);
                if (aluno == null)
                    return RedirectToAction("index");
                else
                    return View("Form", aluno);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }

    }
}
