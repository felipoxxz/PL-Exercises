﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Ex_4._2.Model;
using Ex_4._2.DAO;
using System.Data;
using System.Windows.Forms;

namespace Ex_4._2
{
    public class GameDao
    {
        public static void Insert(GameModel game)
        {
            SqlConnection connection = ConnectionDB.GetConnection();
            string sql = "INSERT INTO jogos values (@id, @descricao, @valor_locacao, @data_aquisicao, @categoria_ID)";
            HelperDAO.ExecutaSql(sql, HelperDAO.CreateParameters(game));
        }
        public static void Update(GameModel game)
        {
            SqlConnection connection = ConnectionDB.GetConnection();
            string sql = "UPDATE jogos set descricao=@descricao, valor_locacao=@valor_locacao, data_aquisicao=@data_aquisicao, categoriaID=@categoria_ID WHERE id = @id";
            HelperDAO.ExecutaSql(sql, HelperDAO.CreateParameters(game));
        }
        public static void Delete(int id) 
        {
            SqlConnection connection = ConnectionDB.GetConnection();
            string sql = "DELETE FROM jogos WHERE id=" + id;
            HelperDAO.ExecutaSql(sql, null);
        }
        public GameModel Search(int id)
        {
            string sql = "select * from jogos where id = " + id;
            DataTable tabela = HelperDAO.ExecutaSql(sql, null);
            if (tabela.Rows.Count == 0)
                return null;
            else
                return BuildModel(tabela.Rows[0]);
        }
        public static GameModel BuildModel(DataRow registro)
        {
            GameModel model = new GameModel();
            model.id = Convert.ToInt32(registro["id"]);
            model.descricao  = registro["descricao"].ToString();
            model.valorLocacao = Convert.ToDecimal(registro["valor_locacao"]);
            model.dataAquisicao = Convert.ToDateTime(registro["data_aquisicao"]);
            model.categoriaId = Convert.ToInt32(registro["categoriaID"]);
            return model;
        }
        public static List<GameModel> AllSearch()
        {
            string sql = "select * from jogos";
            DataTable tabela = HelperDAO.ExecutaSql(sql, null);
            if (tabela.Rows.Count == 0)
                return null;
            else
                return BuildTable(tabela);
        }
        public static List<GameModel> BuildTable(DataTable tabela)
        {
            List<GameModel> model = new List<GameModel>();
            
            foreach (DataRow registro in tabela.Rows)
            {
                model.Add(BuildModel(registro));
            }
            return model;
        }

    }
}
