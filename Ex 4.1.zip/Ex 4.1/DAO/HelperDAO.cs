﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Ex_4._1.Model;
using System.Data;

namespace Ex_4._1.DAO
{
    internal static class HelperDAO
    {
        internal static DataTable ExecutaSql(string sql, SqlParameter[] parametros)
        {
            using (SqlConnection conexao = ConnectionDB.GetConnection())
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conexao))
                {
                    if (parametros != null)
                        adapter.SelectCommand.Parameters.AddRange(parametros);
                    DataTable tabelaTemp = new DataTable();
                    adapter.Fill(tabelaTemp);
                    return tabelaTemp;
                }
            }
        }

        internal static SqlParameter[] CreateParameters(GameModel game)
        {
            SqlParameter[] parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("id", game.id);
            parameters[1] = new SqlParameter("descricao", game.descricao);
            parameters[2] = new SqlParameter("valor_locacao", game.valorLocacao);
            parameters[3] = new SqlParameter("data_aquisicao", game.dataAquisicao);
            parameters[4] = new SqlParameter("categoria_ID", game.categoriaId);
            return parameters;
        }
    }
}
