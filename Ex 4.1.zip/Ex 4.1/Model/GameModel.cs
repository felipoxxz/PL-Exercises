﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex_4._1.Model
{
    public class GameModel
    {
        public int id { get; set; }
        public string descricao { get; set; }
        public decimal valorLocacao { get; set; }
        public DateTime dataAquisicao { get; set; }
        public int categoriaId { get; set; }
    }
}
