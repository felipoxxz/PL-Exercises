﻿using Ex_4._1.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex_4._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Insert(object sender, EventArgs e)
        {
            try
            {
                GameModel model = new GameModel();
                model.id = int.Parse(id.Text);
                model.descricao = descricao.Text;
                model.valorLocacao = decimal.Parse(valor_locacao.Text);
                model.dataAquisicao = Convert.ToDateTime(data_aquisicao.Text);
                model.categoriaId = int.Parse(categoria_id.Text);
                GameDao.Insert(model);
                Clear();
                MessageBox.Show("Sucesso ao inserir o jogo");

            }
            catch (Exception)
            {   
                MessageBox.Show("Erro ao inserir, por favor verifique os dados inseridos");
            }
        }

        private void Update(object sender, EventArgs e)
        {
            try
            {
                GameModel model = new GameModel();
                model.id = int.Parse(id.Text);
                model.descricao = descricao.Text;
                model.valorLocacao = decimal.Parse(valor_locacao.Text);
                model.dataAquisicao = Convert.ToDateTime(data_aquisicao.Text);
                model.categoriaId = int.Parse(categoria_id.Text);
                GameDao.Update(model);
                Clear();
                MessageBox.Show("Sucesso ao alterar o jogo");

            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar, por favor verifique os dados inseridos");
            }
        }

        private void Delete(object sender, EventArgs e)
        {
            try
            {
                int idgame = int.Parse(id.Text);
                GameDao.Delete(idgame);
                Clear();
                MessageBox.Show("Sucesso ao excluir o jogo");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao inserir, por favor verifique os dados inseridos");
            }
        }
        private void FillScreen(GameModel a)
        {
            if (a != null)
            {
                id.Text = a.id.ToString();
                descricao.Text = a.descricao;
                valor_locacao.Text = a.valorLocacao.ToString();
                data_aquisicao.Text = a.dataAquisicao.ToShortDateString();
                categoria_id.Text = a.categoriaId.ToString();
            }
        }

        private void Search(object sender, EventArgs e)
        {
            try
            {
                GameDao dao = new GameDao();
                GameModel a = dao.Search(Convert.ToInt32(id.Text));
                if (a != null)
                    FillScreen(a);
                else
                    MessageBox.Show("Registro não encontrado!");
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
            }
        }

        //private void AllSearch(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        List<GameModel> tabela = GameDao.AllSearch();
        //        dataGridView1.DataSource = tabela;
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //}
        private void Clear()
        {
            id.Clear();
            descricao.Clear();
            valor_locacao.Clear();
            data_aquisicao.Clear();
            categoria_id.Clear();
        }
    }
}
