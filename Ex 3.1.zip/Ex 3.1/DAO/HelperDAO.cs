﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Ex_3._1.Model;

namespace Ex_3._1.DAO
{
    internal static class HelperDAO
    {
        internal static void ExecutaSql(string sql, SqlParameter[] parameters)
        {
            using(SqlConnection connection = ConectionDB.GetConnection())
            {
                using(SqlCommand command = new SqlCommand(sql, connection))
                {
                    if(parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    command.ExecuteNonQuery();
                }
            }
        }
        internal static SqlParameter[] CreateParameters(GameModel game)
        {
            SqlParameter[] parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("id", game.id);
            parameters[1] = new SqlParameter("descricao", game.descricao);
            parameters[2] = new SqlParameter("valor_locacao", game.valorLocacao);
            parameters[3] = new SqlParameter("data_aquisicao", game.dataAquisicao);
            parameters[4] = new SqlParameter("categoria_ID", game.categoriaId);
            return parameters;
        }
    }
}
