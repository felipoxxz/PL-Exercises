﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Ex_3._1.Model;
using Ex_3._1.DAO;

namespace Ex_3._1
{
    public class GameDao
    {
        public static void Insert(GameModel game)
        {
            SqlConnection connection = ConectionDB.GetConnection();
            string sql = "INSERT INTO jogos values (@id, @descricao, @valor_locacao, @data_aquisicao, @categoria_ID)";
            HelperDAO.ExecutaSql(sql, HelperDAO.CreateParameters(game));
        }
        public static void Update(GameModel game)
        {
            SqlConnection connection = ConectionDB.GetConnection();
            string sql = "UPDATE jogos set descricao=@descricao, valor_locacao=@valor_locacao, data_aquisicao=@data_aquisicao, categoriaID=@categoria_ID WHERE id = @id";
            HelperDAO.ExecutaSql(sql, HelperDAO.CreateParameters(game));
        }
        public static void Delete(int id) 
        {
            SqlConnection connection = ConectionDB.GetConnection();
            string sql = "DELETE FROM jogos WHERE id=" + id;
            HelperDAO.ExecutaSql(sql, null);
        }
        
    }
}
