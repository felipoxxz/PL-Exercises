using Ex_10._1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Ex_10._1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult EfetuaPotencia(double valor1, double valor2)
        {
            double resultado = Math.Pow(valor1, valor2);
            return View("Index", resultado);
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
