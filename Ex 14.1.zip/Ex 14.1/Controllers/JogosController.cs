﻿using Ex_14._1.DAO;
using Ex_14._1.Models;
using Microsoft.AspNetCore.Mvc;

namespace Ex_14._1.Controllers
{
    public class JogosController : Controller
    {
        public IActionResult Index()
        {
            List<JogosViewModel> listModel = new List<JogosViewModel>();
            listModel = GameDAO.AllSearch();
            return View(listModel);
        }
        public IActionResult Create()
        {
            JogosViewModel aluno = new JogosViewModel();
            aluno.dataAquisicao = DateTime.Now;
            return View("Form", aluno);
        }

        public IActionResult Salvar(JogosViewModel aluno)
        {
            GameDAO.Insert(aluno);
            return RedirectToAction("index");
        }
    }
}
