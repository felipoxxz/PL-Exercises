﻿using Ex_14._1.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
using System.Data.SqlClient;

namespace Ex_14._1.DAO
{
    public class GameDAO
    {
        public static void Insert(JogosViewModel game)
        {
            SqlConnection connection = ConnectionDB.GetConnection();
            if(game.dataAquisicao == DateTime.MinValue ) 
            { 
                game.dataAquisicao = DateTime.Now;
            }
            string sql = "INSERT INTO jogos values (@id, @descricao, @valor_locacao, @data_aquisicao, @categoriaID)";
            HelperDAO.ExecutaSql(sql, HelperDAO.CreateParameters(game));
        }
        public static List<JogosViewModel> AllSearch()
        {
            string sql = "select * from jogos order by id";
            DataTable tabela = HelperDAO.ExecutaSql(sql, null);
            if (tabela.Rows.Count == 0)
                return null;
            else
                return BuildTable(tabela);
        }
        public static List<JogosViewModel> BuildTable(DataTable tabela)
        {
            List<JogosViewModel> model = new List<JogosViewModel>();

            foreach (DataRow registro in tabela.Rows)
            {
                model.Add(BuildModel(registro));
            }
            return model;
        }
        private static JogosViewModel BuildModel(DataRow registro)
        {
            JogosViewModel model = new JogosViewModel();
            model.id = Convert.ToInt32(registro["id"]);
            model.descricao = registro["descricao"].ToString();
            model.valorLocacao = Convert.ToDecimal(registro["valor_locacao"]);
            model.dataAquisicao = Convert.ToDateTime(registro["data_aquisicao"]);
            model.categoriaId = Convert.ToInt32(registro["categoriaID"]);
            return model;
        }
    }
}
